package javastudy.day3;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.Scanner;

public class Test{
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        System.out.println("년");
        int year = scanner.nextInt();

        System.out.println("월 입력");
        int month = scanner.nextInt();

        Calendar cal = Calendar.getInstance();
        cal.set(year, month-1. 1);

        int starweek = cal.get(Calendar.DAY_OF_WEEK);
        int DayOfMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        String weekNames[] = {"일", "월", "화", "수", "목", "금", "토"};

        for(String weekName : weekName){
            System.out.println(weekName+"\t");
        }System.out.println();

        int step = 0;

        for(int i=1; i <= starweek-1; i++){
            System.out.println("\t");
            step++;
        }
        for(int i=1; i<=DayOfMonth; i++){
            System.out.println(i+"\t");
            step++;
            if(i%7==0){
                System.out.println();
            }
        }
        
    }
}