package swing4;

public class Winmain {

    public static void main(String[] args) {

        Window win = new Window();
        win.initLottoLayout();
    }
}