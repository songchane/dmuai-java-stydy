package swing4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MemberTest {

    public static void main(String[] args){
        MemberService memberService = new MemberService();

        //String userName = memberService.getUserName("20221660");
        //System.out.println(userName);

        String userId = "lcs";
        String userName = "이찬송";
        String userPassword = "1234";

        memberService.addMember(userId, userName, userPassword);

    }

}