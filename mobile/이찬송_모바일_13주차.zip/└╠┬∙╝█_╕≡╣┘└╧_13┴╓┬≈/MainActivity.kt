package com.example.a12_qa

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.*
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.a12_qa.databinding.ActivityMainBinding
import com.example.a12_qa.databinding.ItemMainBinding

class JobViewHolder(val adapter: JobAdapter, val binding: ItemMainBinding) : RecyclerView.ViewHolder(binding.root) {
    init {
        itemView.setOnClickListener {
            if(adapter.selectedItemPos != -1)
                adapter.notifyItemChanged(adapter.selectedItemPos)
            adapter.selectedItemPos = adapterPosition
            adapter.notifyItemChanged(adapter.selectedItemPos)
        }
    }

    fun defaultBg() {
        binding.root.background = binding.root.context.getDrawable(R.drawable.item_unselected)
    }

    fun selectedBg() {
        binding.root.background = binding.root.context.getDrawable(R.drawable.item_selected)
    }

    fun viewBind(pos:Int) {
        if(pos == adapter.selectedItemPos)
            selectedBg()
        else
            defaultBg()

        with(binding) {
            val img = adapter.datas[pos].get("img")
            val title = adapter.datas[pos].get("title")
            val who = adapter.datas[pos].get("who")
            textViewState.apply {
                when(img?.toInt()) {
                    R.drawable.shape_yellow -> text = "준비중"
                    R.drawable.shape_red -> text = "진행중"
                    R.drawable.shape_blue -> text = "완료"
                }
            }
            imageView.setImageResource(img!!.toInt())
            textViewInfo.text = title
            textViewWho.text = who
        }
    }
}

// img, title, detail, who
class JobAdapter(val datas:MutableList<MutableMap<String,String>>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    var selectedItemPos:Int = -1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = ItemMainBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return JobViewHolder(this, binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as JobViewHolder).viewBind(position)
    }

    override fun getItemCount(): Int {
        return datas.size
    }
}

class MainActivity : AppCompatActivity() { // mainActivity
    lateinit var binding: ActivityMainBinding
    var searchView: SearchView? = null
    lateinit var launcher:ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        val contract = ActivityResultContracts.StartActivityForResult()
        val callback = object:ActivityResultCallback<ActivityResult> {
            override fun onActivityResult(result: ActivityResult?) {
                if(result?.resultCode == RESULT_OK) {
                    val intent = result?.data
                    val no = intent?.getIntExtra("no", -1)
                    val strTitle = intent?.getStringExtra("title")
                    val strDetail = intent?.getStringExtra("detail")
                    val strWho = intent?.getStringExtra("who")
                    val state = intent?.getIntExtra("state", 0)

                    val item = mutableMapOf<String, String>()
                    item.put("title", strTitle!!)
                    item.put("detail", strDetail!!)
                    item.put("who", strWho!!)
                    item.put(
                        "img", when (state) {
                            0 -> R.drawable.shape_yellow.toString()
                            1 -> R.drawable.shape_red.toString()
                            2 -> R.drawable.shape_blue.toString()
                            else -> R.drawable.shape_yellow.toString()
                        }
                    )
                    if (no == -1) {
                        (binding.recyclerView.adapter as JobAdapter).datas.add(item)
                        (binding.recyclerView.adapter as JobAdapter).notifyDataSetChanged()
                    } else {
                        (binding.recyclerView.adapter as JobAdapter).datas.set(no!!, item)
                        (binding.recyclerView.adapter as JobAdapter).notifyItemChanged(no!!)
                    }
                } else
                    Toast.makeText(applicationContext, "취소되었습니다", Toast.LENGTH_LONG).show()
            }
        }
        launcher = registerForActivityResult(contract, callback)

        // img, title, detail, who
        val datas = mutableListOf<MutableMap<String,String>>()
        var data = mutableMapOf<String,String>()
        data.put("img", R.drawable.shape_yellow.toString())
        data.put("title","기획서 작성")
        data.put("who","")
        data.put("detail","장바구니 활용")
        datas.add(data)

        data = mutableMapOf<String,String>()
        data.put("img", R.drawable.shape_red.toString())
        data.put("title","Q&A 게시판 개발")
        data.put("who","이찬송")
        data.put("detail","file.docx")
        datas.add(data)

        data = mutableMapOf<String,String>()
        data.put("img", R.drawable.shape_blue.toString())
        data.put("title","Q&A 게시판 디자인")
        data.put("who","신예찬")
        data.put("detail","file.docx")
        datas.add(data)

        val adapter = JobAdapter(datas)
        binding.recyclerView.adapter = adapter
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.addItemDecoration(DividerItemDecoration(this, LinearLayoutManager.VERTICAL))

    } // onCreate

    fun editJob(adapter: JobAdapter) {
        if(adapter.selectedItemPos != -1) {
            val data = adapter.datas.get(adapter.selectedItemPos)
            val intent = Intent(this, EditActivity::class.java)
            val state = when(data.get("img")?.toInt()) {
                R.drawable.shape_red -> 1
                R.drawable.shape_blue -> 2
                else -> 0
            }
            intent.putExtra("no", adapter.selectedItemPos)
            intent.putExtra("state",state )
            intent.putExtra("name", data.get("title"))
            intent.putExtra("detail", data.get("detail"))
            intent.putExtra("toWhom", data.get("who"))
            launcher?.launch(intent)
        } else
            Toast.makeText(this, "항목을 선택해 주세요.", Toast.LENGTH_SHORT).show()
    }

    fun delJob(adapter: JobAdapter) {
        if(adapter.selectedItemPos != -1) {
            (binding.recyclerView.adapter as JobAdapter).datas.removeAt(adapter.selectedItemPos)
            (binding.recyclerView.adapter as JobAdapter).notifyDataSetChanged()

        } else
            Toast.makeText(applicationContext, "항목을 선택해 주세요", Toast.LENGTH_LONG).show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        val menuItem = menu?.findItem(R.id.menuSearch)
        searchView = menuItem?.actionView as SearchView
        searchView?.queryHint = "검색어 입력"

        val textView: TextView? = searchView?.findViewById<View>(androidx.appcompat.R.id.search_src_text) as TextView
        textView?.setTextColor(Color.WHITE)
        textView?.setHintTextColor(Color.WHITE)

        searchView?.setOnQueryTextListener(object:SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                Toast.makeText(applicationContext, query, Toast.LENGTH_LONG).show()
                searchView?.isIconified = true
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                return true
            }
        })
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId) {
            R.id.menuAdd -> {
                val intent = Intent(this, EditActivity::class.java)
                intent.putExtra("no", -1)
                launcher.launch(intent)
            }//Toast.makeText(applicationContext, "추가", Toast.LENGTH_LONG).show()
            R.id.menuEdit -> editJob(binding.recyclerView.adapter as JobAdapter) //Toast.makeText(applicationContext, "수정", Toast.LENGTH_LONG).show()
            R.id.menuDel -> { delJob(binding.recyclerView.adapter as JobAdapter)
            }//Toast.makeText(applicationContext, "삭제", Toast.LENGTH_LONG).show()
        }
        return super.onOptionsItemSelected(item)
    }
}