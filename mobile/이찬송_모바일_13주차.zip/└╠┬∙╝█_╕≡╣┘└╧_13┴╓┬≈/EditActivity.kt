package com.example.a12_qa

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.a12_qa.databinding.ActivityEditBinding

class EditActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_edit)
        val binding = ActivityEditBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val no = intent.getIntExtra("no", -1)
        if(no != -1) { // 수정 메뉴 클릭해서 넘어져 온 경우
            val state = intent.getIntExtra("state", 0)
            val name = intent.getStringExtra("name")
            val detail = intent.getStringExtra("detail")
            val who = intent.getStringExtra("toWhom")

            binding.editTextName.setText(name)
            binding.editTextDetail.setText(detail)
            binding.editTextToWhom.setText(who)
            when(state) {
                0 -> binding.radioButtonWait.isChecked = true
                1 -> binding.radioButtonIng.isChecked = true
                2 -> binding.radioButtonDone.isChecked = true
            }
        }

        binding.buttonCancel.setOnClickListener {
            finish()
        }

        binding.buttonOk.setOnClickListener{
            val strTitle = binding.editTextName.text.toString().trim()
            val strDetail = binding.editTextDetail.text.toString().trim()

            if(strTitle.isEmpty() || strDetail.isEmpty()) {
                Toast.makeText(applicationContext, "입력하세요.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            val state = when(binding.radioGroupState.checkedRadioButtonId) {
                R.id.radioButtonWait -> 0
                R.id.radioButtonIng -> 1
                R.id.radioButtonDone -> 2
                else -> 0
            }
            val strWho = binding.editTextToWhom.text.toString().trim()
            if(state != 0 && strWho.isEmpty()) {
                Toast.makeText(applicationContext, "담당자를 입력하세요", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val intent = Intent()
            intent.apply{
                putExtra("no", no)
                putExtra("state", state)
                putExtra("title", strTitle)
                putExtra("detail", strDetail)
                putExtra("who", strWho)
            }
            setResult(RESULT_OK, intent)
            finish()
        }
    }
}