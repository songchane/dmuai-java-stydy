package com.example.a10_qa

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.a10_qa.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.imageView.setOnClickListener{
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:37.49830237165004,126.86714535159363"))
            startActivity(intent)
        }

        binding.button.setOnClickListener {
            val intent1 = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.dongyang.ac.kr/"))
            startActivity(intent1)
        }

        binding.button2.setOnClickListener {
            val intent2 = Intent(Intent.ACTION_DIAL, Uri.parse("tel:02-2610-1700"))
            startActivity(intent2)
        }

        binding.textView.setOnClickListener {
            val intent3 = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.dongyang.ac.kr/sites/dmu_23259/index.do"))
            startActivity(intent3)
        }


    }
}