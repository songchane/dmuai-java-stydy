package com.example.a09_qa

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.DialogInterface
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.KeyEvent
import android.widget.DatePicker
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.example.a09_qa.databinding.ActivityMainBinding
import java.time.LocalDate

class MainActivity : AppCompatActivity() { // mainActivity
    var keyback:Int = 0         //변수 선언
    var roomType:Int = 0
    lateinit var binding:ActivityMainBinding


    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val today = LocalDate.now()
        binding.textViewDate.text="${today.year}.${today.monthValue}.${today.dayOfMonth}"
        binding.buttonSelDate.setOnClickListener {


            /* val dateDlg = DatePickerDialog(this@MainActivity, object:DatePickerDialog.OnDateSetListener{
                override fun onDateSet(p0: DatePicker?, p1: Int, p2: Int, p3: Int) {
                    if(p1 < today.year || (p2 + 1) < today.monthValue || p3 < today.dayOfMonth){
                        Toast.makeText(applicationContext, "오늘 날짜보다 이전 날짜는 선택하지 못합니다.", Toast.LENGTH_LONG).show()
                        return
                    }
                    binding.textViewDate.text = "${p1}.${p2+1}.${p3}"
                }
            },
            today.year, today.monthValue-1, today.dayOfMonth)
            dateDlg.show() */


        DatePickerDialog(this@MainActivity, object:DatePickerDialog.OnDateSetListener{
            override fun onDateSet(p0: DatePicker?, p1: Int, p2: Int, p3: Int) {
                if(p1 < today.year || (p2 + 1) < today.monthValue || p3 < today.dayOfMonth){
                    Toast.makeText(applicationContext, "오늘 날짜보다 이전 날짜는 선택하지 못합니다.", Toast.LENGTH_LONG).show()
                    return
                }
                binding.textViewDate.text = "${p1}.${p2+1}.${p3}"
            }
        },
            today.year, today.monthValue-1, today.dayOfMonth).show()

        } //setOnClickListener

        binding.buttonSelRoom.setOnClickListener {
            val builder = AlertDialog.Builder(this@MainActivity)
            val items = arrayOf<String>(getString(R.string.room1), getString(R.string.room4), getString(R.string.room8), getString(R.string.roomL))
            builder.setTitle("룸 선택")
            builder.setSingleChoiceItems(items, roomType, object :DialogInterface.OnClickListener{
                override fun onClick(p0: DialogInterface?, p1: Int) {
                    roomType = p1
                    Toast.makeText(applicationContext, items[p1], Toast.LENGTH_LONG).show()
                }

            })

            builder.setPositiveButton("Ok", object : DialogInterface.OnClickListener {
                override fun onClick(p0: DialogInterface?, p1: Int) {
                    binding.textViewRoom.text = items[roomType]
                    p0?.dismiss()
                }

            })

            builder.setNegativeButton("Cancel", null)
            builder.setCancelable(false) // 뒤로가기 눌러도 창이 사라지지 않음이
            val dlg = builder.show()
            dlg.setCanceledOnTouchOutside(false) // 바깥을 터치해도 창이 사라지지 않음

        } // setOnClickListener

        binding.buttonOk.setOnClickListener {
            val strName = binding.editTextName.text.toString().trim()
            val strPhone = binding.editTextPhone.text.toString().trim()

            if(strName.isEmpty() || strPhone.isEmpty()) {
                Toast.makeText(applicationContext, "정보를 기입해 주세요.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val strPersons = binding.editTextPersons.text.toString().trim()
            if((roomType == 0 || roomType == 3) && (strPersons.isEmpty() || strPersons.toInt() == 0)){
                Toast.makeText(applicationContext, "인원수를 정확히 입력해 주세요.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val builder = AlertDialog.Builder(this@MainActivity)
                builder.setTitle("예약 확인")
                builder.setMessage("예약하시겠습니까?")

                builder.setPositiveButton("Ok", object : DialogInterface.OnClickListener {
                    override fun onClick(dialog: DialogInterface?, which: Int) {
                        Toast.makeText(applicationContext, "예약되었습니다.", Toast.LENGTH_SHORT).show()
                    }

                })
                builder.setNegativeButton("Cancel", object : DialogInterface.OnClickListener {
                    override fun onClick(dialog: DialogInterface?, which: Int) {
                        Toast.makeText(applicationContext, "예약이 취소되었습니다.", Toast.LENGTH_SHORT)
                            .show()
                    }

                })

                builder.setCancelable(false)
                builder.show().setCanceledOnTouchOutside(false)


        } // setOnClickListener

    } //oncreate

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if(keyCode == KeyEvent.KEYCODE_BACK){
            if(keyback == 0) {
                keyback++
                Toast.makeText(applicationContext, "뒤로가기 버튼을 한번 더 누르면 종료됩니다.", Toast.LENGTH_LONG).show()
                return false
            }
        }
        return super.onKeyDown(keyCode, event)
    } // onKeyDown

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("date", binding.textViewDate.text.toString())
        outState.putString("room", binding.textViewRoom.text.toString())
    }

    override fun onRestoreInstanceState(savedState: Bundle) {
        super.onRestoreInstanceState(savedState)
        binding.textViewDate.text = savedState.getString("date")
        binding.textViewRoom.text = savedState.getString("room")
    }

}