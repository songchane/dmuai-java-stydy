package com.example.a11_qa

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import com.example.a11_qa.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    var total:Int = 0
    val totalPeople:Array<Int> = Array(3, {0})

    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val contract = ActivityResultContracts.StartActivityForResult()
        val callback = object:ActivityResultCallback<ActivityResult>{
            override fun onActivityResult(result: ActivityResult?) {
                if(result?.resultCode == RESULT_OK){
                    val intent:Intent? = result?.data
                    val person = intent?.getIntExtra("person", 0)
                    val gender = intent?.getStringExtra("gender")
                    val ages = intent?.getStringExtra("ages")
                    total++
                    totalPeople[person!! - 1]++

                    val strMsg = "${getString(R.string.ptotal)} ${totalPeople[person!!-1]}${getString(R.string.person)}"
                    when(person) {
                        1 -> binding.textViewP1T.text = strMsg
                        2 -> binding.textViewP2T.text = strMsg
                        3 -> binding.textViewP3T.text = strMsg
                    }

                    binding.textViewT.text = "${getString(R.string.total)} ${total}${getString(R.string.person)}"
                    Toast.makeText(applicationContext, "성별:" + gender + "\n 나이:" + ages , Toast.LENGTH_SHORT).show()


                }else {
                    Toast.makeText(applicationContext, "취소되었습니다.", Toast.LENGTH_SHORT).show()
                }
            }

        }
        val launcher = registerForActivityResult(contract, callback)


        val listener = object:View.OnClickListener{
            override fun onClick(p0: View?) {
                val intent = Intent(this@MainActivity, DetailActivity::class.java)
                var person = when(p0?.id){
                    R.id.imageViewP1 -> 1
                    R.id.imageViewP2 -> 2
                    R.id.imageViewP3 -> 3
                    else -> 0
                }
                var personName = when(p0?.id){
                    R.id.imageViewP1 -> "이 XX"
                    R.id.imageViewP2 -> "윤 XX"
                    R.id.imageViewP3 -> "심 XX"
                    else -> 0
                }

                intent.putExtra("personName",personName)
                intent.putExtra("person", person)
                launcher.launch(intent)
                //startActivity(intent)
            }
        }


        val listener2 = object :View.OnClickListener {
            override fun onClick(v: View?) {
                val intent = Intent(this@MainActivity, DetailActivity::class.java)
                intent.putExtra("name", "이 XX")
                intent.putExtra("name", "윤 XX")
                intent.putExtra("name", "심 XX")
            }
        }

        binding.imageViewP1.setOnClickListener(listener)
        binding.imageViewP2.setOnClickListener(listener)
        binding.imageViewP3.setOnClickListener(listener)

    } //onCreate
} //MainActivity