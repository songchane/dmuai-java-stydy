package com.example.a11_qa

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.a11_qa.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var person = intent.getIntExtra("person", 0)
        var personName = intent.getStringExtra("personName")
        binding.textViewPerson.text = "${personName}${getString(R.string.detail_msg)}"

        binding.buttonOk.setOnClickListener{
            val intent = Intent()
            intent.putExtra("person", person)
            intent.putExtra("gender", if(binding.gender.checkedRadioButtonId == R.id.radioButtonM) "남자" else "여자")
            intent.putExtra("ages",
                when(binding.age.checkedRadioButtonId){
                    R.id.radioButton10 -> "10대"
                    R.id.radioButton20 -> "20대"
                    R.id.radioButton30 -> "30대"
                    R.id.radioButton40 -> "40대"
                    R.id.radioButton50 -> "50대"
                    R.id.radioButton60 -> "60대"
                    else -> ""
                })
            setResult(RESULT_OK, intent)
            finish()
        } //binding.buttonOk.setOnClickListener

        binding.buttonCancel.setOnClickListener{
            finish()
        }

    } //onCreate
}